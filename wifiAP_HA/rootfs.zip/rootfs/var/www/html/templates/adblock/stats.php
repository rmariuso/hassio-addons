<!-- statistics tab -->
<div class="tab-pane fade" id="adblockstats">
  <h4 class="mt-3"><?php echo _("Statistics"); ?></h4>
    <div class="row">
      <div class="form-group col-md-8">
        <?php
        /*
         * BZ todo: implement basic stats
         *
         */
        ?>
    </div>
  </div>
</div><!-- /.tab-pane -->

